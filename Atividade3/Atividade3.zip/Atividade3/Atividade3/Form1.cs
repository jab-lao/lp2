namespace Atividade3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtWeight_TextChanged(object sender, EventArgs e)
        {
            int number = 0;

            if (!int.TryParse(txtWeight.Text, out number) && txtWeight.Text != "")
            {
                txtWeight.Text = txtWeight.Text.Remove(txtWeight.Text.Length - 1, 1);
                txtWeight.Select(txtWeight.Text.Length, 0);
            }


        }

        private void txtHeight_TextChanged(object sender, EventArgs e)
        {
            int number = 0;

            if (!int.TryParse(txtHeight.Text, out number) && txtHeight.Text != "")
            {
                txtHeight.Text = txtHeight.Text.Remove(txtHeight.Text.Length - 1, 1);
                txtHeight.Select(txtHeight.Text.Length, 0);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtHeight.Text != "" && txtWeight.Text != "")
            {
                float height = float.Parse(txtHeight.Text) / 100;
                float weight = float.Parse(txtWeight.Text);

                float imc = weight / (height * height);

                if (imc < 18.5) {
                    MessageBox.Show("Seu IMC �: " + imc.ToString("0.0") + "\nSua classifica��o �: Magreza.");
                }
                if (imc >= 18.5 && imc <= 24.9)
                {
                    MessageBox.Show("Seu IMC �: " + imc.ToString("0.0") + "\nSua classifica��o �: Normal.");
                }
                if (imc > 24.9 && imc <= 29.9)
                {
                    MessageBox.Show("Seu IMC �: " + imc.ToString("0.0") + "\nSua classifica��o �: Sobrepeso.");
                }
                if (imc > 29.9 && imc < 39.9)
                {
                    MessageBox.Show("Seu IMC �: " + imc.ToString("0.0") + "\nSua classifica��o �: Obesidade.");
                }
                if (imc > 39.9)
                {
                    MessageBox.Show("Seu IMC �: " + imc.ToString("0.0") + "\nSua classifica��o �: Obesidade M�rbida.");
                }
            }
        }
    }
}
