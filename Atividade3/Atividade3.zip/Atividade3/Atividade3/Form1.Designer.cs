﻿namespace Atividade3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtWeight = new TextBox();
            txtHeight = new TextBox();
            label3 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.DarkSlateBlue;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            label1.ForeColor = Color.SpringGreen;
            label1.Location = new Point(76, 134);
            label1.Name = "label1";
            label1.Size = new Size(141, 32);
            label1.TabIndex = 0;
            label1.Text = "  Peso (kg) ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.DarkSlateBlue;
            label2.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            label2.ForeColor = Color.SpringGreen;
            label2.Location = new Point(76, 227);
            label2.Name = "label2";
            label2.Size = new Size(144, 32);
            label2.TabIndex = 1;
            label2.Text = "Altura (cm)";
            // 
            // txtWeight
            // 
            txtWeight.Location = new Point(76, 169);
            txtWeight.Name = "txtWeight";
            txtWeight.Size = new Size(144, 32);
            txtWeight.TabIndex = 2;
            txtWeight.TextChanged += txtWeight_TextChanged;
            // 
            // txtHeight
            // 
            txtHeight.Location = new Point(76, 262);
            txtHeight.Name = "txtHeight";
            txtHeight.Size = new Size(144, 32);
            txtHeight.TabIndex = 3;
            txtHeight.TextChanged += txtHeight_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.DarkSlateBlue;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Segoe UI", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.SpringGreen;
            label3.Location = new Point(28, 9);
            label3.Name = "label3";
            label3.Size = new Size(230, 102);
            label3.TabIndex = 4;
            label3.Text = "Calculadora\r\n    de IMC";
            // 
            // button1
            // 
            button1.BackColor = Color.MediumAquamarine;
            button1.FlatAppearance.BorderSize = 4;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.DarkSlateBlue;
            button1.Location = new Point(49, 320);
            button1.Name = "button1";
            button1.Size = new Size(200, 41);
            button1.TabIndex = 5;
            button1.Text = "eu estou gordo?";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleMode = AutoScaleMode.None;
            AutoSize = true;
            BackColor = Color.MediumSlateBlue;
            ClientSize = new Size(291, 381);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(txtHeight);
            Controls.Add(txtWeight);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 14F);
            Margin = new Padding(5);
            MaximizeBox = false;
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtWeight;
        private TextBox txtHeight;
        private Label label3;
        private Button button1;
    }
}
