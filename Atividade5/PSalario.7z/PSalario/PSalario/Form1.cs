namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double salabrio = Convert.ToDouble(txtSalBruto.Text);
            double aliquotaINSS, aliquotaIRPF, salFamilia;


            if (salabrio < 800.48) aliquotaINSS = 7.65;
            else if (salabrio < 1050.01) aliquotaINSS = 8.65;
            else if (salabrio < 1400.78) aliquotaINSS = 9;
            else if (salabrio < 2801.57) aliquotaINSS = 11;
            else aliquotaINSS = 99;

            if (salabrio < 1257.13) aliquotaIRPF = 0;
            else if (salabrio < 2512.09) aliquotaIRPF = 15;
            else aliquotaIRPF = 27.5;

            if (salabrio < 435.53) salFamilia = 22.33 * Convert.ToInt32(txtNumFilhos.Text);
            else if (salabrio < 654.62) salFamilia = 15.74 * Convert.ToInt32(txtNumFilhos.Text);
            else salFamilia = 0;

            if (aliquotaINSS != 99)
            {
                txtAliquotaINSS.Text = aliquotaINSS.ToString() + "%";
                txtDescontoINSS.Text = (Math.Round(aliquotaINSS / 100, 2) * salabrio).ToString();
            }
            else
            {
                txtAliquotaINSS.Text = "Teto";
                txtDescontoINSS.Text = (Math.Round((27.5 / 100) * salabrio, 2)).ToString();
            }

            txtAliquotaIRPF.Text = aliquotaIRPF.ToString() + "%";
            txtDescontoIRPF.Text = (Math.Round((aliquotaIRPF / 100) * salabrio, 2) ).ToString();

            txtSalFamilia.Text = salFamilia.ToString();

            txtSalLiquido.Text = (salabrio - (Convert.ToDouble(txtDescontoINSS.Text))
                - (Convert.ToDouble(txtDescontoIRPF.Text))
                + salFamilia
                ).ToString();
        }
    }
}
