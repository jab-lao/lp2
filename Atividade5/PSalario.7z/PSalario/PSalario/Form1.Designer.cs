﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtNome = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            txtNumFilhos = new NumericUpDown();
            txtAliquotaINSS = new TextBox();
            txtAliquotaIRPF = new TextBox();
            txtSalFamilia = new TextBox();
            txtSalLiquido = new TextBox();
            txtDescontoINSS = new TextBox();
            txtDescontoIRPF = new TextBox();
            button1 = new Button();
            maskedTextBox1 = new MaskedTextBox();
            txtSalBruto = new MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)txtNumFilhos).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(28, 32);
            label1.Name = "label1";
            label1.Size = new Size(286, 38);
            label1.TabIndex = 0;
            label1.Text = "Nome do Funcionário";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(28, 83);
            label2.Name = "label2";
            label2.Size = new Size(175, 38);
            label2.TabIndex = 1;
            label2.Text = "Salário Bruto";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(28, 134);
            label3.Name = "label3";
            label3.Size = new Size(238, 38);
            label3.TabIndex = 2;
            label3.Text = "Número de Filhos";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(28, 327);
            label4.Name = "label4";
            label4.Size = new Size(186, 38);
            label4.TabIndex = 3;
            label4.Text = "Alíquota INSS";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(28, 378);
            label5.Name = "label5";
            label5.Size = new Size(182, 38);
            label5.TabIndex = 4;
            label5.Text = "Alíquota IRPF";
            // 
            // txtNome
            // 
            txtNome.AutoSize = true;
            txtNome.Location = new Point(28, 429);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(194, 38);
            txtNome.TabIndex = 5;
            txtNome.Text = "Salário Família";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(28, 480);
            label7.Name = "label7";
            label7.Size = new Size(199, 38);
            label7.TabIndex = 6;
            label7.Text = "Salário Líquido";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(521, 331);
            label8.Name = "label8";
            label8.Size = new Size(200, 38);
            label8.TabIndex = 8;
            label8.Text = "Desconto INSS";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(521, 382);
            label9.Name = "label9";
            label9.Size = new Size(196, 38);
            label9.TabIndex = 9;
            label9.Text = "Desconto IRPF";
            // 
            // txtNumFilhos
            // 
            txtNumFilhos.Location = new Point(344, 127);
            txtNumFilhos.Name = "txtNumFilhos";
            txtNumFilhos.Size = new Size(373, 45);
            txtNumFilhos.TabIndex = 12;
            // 
            // txtAliquotaINSS
            // 
            txtAliquotaINSS.Enabled = false;
            txtAliquotaINSS.Location = new Point(233, 320);
            txtAliquotaINSS.Name = "txtAliquotaINSS";
            txtAliquotaINSS.Size = new Size(261, 45);
            txtAliquotaINSS.TabIndex = 13;
            // 
            // txtAliquotaIRPF
            // 
            txtAliquotaIRPF.Enabled = false;
            txtAliquotaIRPF.Location = new Point(233, 371);
            txtAliquotaIRPF.Name = "txtAliquotaIRPF";
            txtAliquotaIRPF.Size = new Size(261, 45);
            txtAliquotaIRPF.TabIndex = 14;
            // 
            // txtSalFamilia
            // 
            txtSalFamilia.Enabled = false;
            txtSalFamilia.Location = new Point(233, 422);
            txtSalFamilia.Name = "txtSalFamilia";
            txtSalFamilia.Size = new Size(261, 45);
            txtSalFamilia.TabIndex = 15;
            // 
            // txtSalLiquido
            // 
            txtSalLiquido.Enabled = false;
            txtSalLiquido.Location = new Point(233, 473);
            txtSalLiquido.Name = "txtSalLiquido";
            txtSalLiquido.Size = new Size(261, 45);
            txtSalLiquido.TabIndex = 16;
            // 
            // txtDescontoINSS
            // 
            txtDescontoINSS.Enabled = false;
            txtDescontoINSS.Location = new Point(727, 324);
            txtDescontoINSS.Name = "txtDescontoINSS";
            txtDescontoINSS.Size = new Size(221, 45);
            txtDescontoINSS.TabIndex = 17;
            // 
            // txtDescontoIRPF
            // 
            txtDescontoIRPF.Enabled = false;
            txtDescontoIRPF.Location = new Point(727, 375);
            txtDescontoIRPF.Name = "txtDescontoIRPF";
            txtDescontoIRPF.Size = new Size(221, 45);
            txtDescontoIRPF.TabIndex = 18;
            // 
            // button1
            // 
            button1.Location = new Point(344, 219);
            button1.Name = "button1";
            button1.Size = new Size(252, 50);
            button1.TabIndex = 19;
            button1.Text = "Verificar Desconto";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // maskedTextBox1
            // 
            maskedTextBox1.Location = new Point(344, 25);
            maskedTextBox1.Mask = "LLLLLLLLLLLLLLLLLLLLLLLLLLLL";
            maskedTextBox1.Name = "maskedTextBox1";
            maskedTextBox1.Size = new Size(349, 45);
            maskedTextBox1.TabIndex = 10;
            // 
            // txtSalBruto
            // 
            txtSalBruto.Location = new Point(344, 76);
            txtSalBruto.Mask = "00000.00";
            txtSalBruto.Name = "txtSalBruto";
            txtSalBruto.Size = new Size(349, 45);
            txtSalBruto.TabIndex = 11;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(15F, 38F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1021, 583);
            Controls.Add(txtSalBruto);
            Controls.Add(maskedTextBox1);
            Controls.Add(button1);
            Controls.Add(txtDescontoIRPF);
            Controls.Add(txtDescontoINSS);
            Controls.Add(txtSalLiquido);
            Controls.Add(txtSalFamilia);
            Controls.Add(txtAliquotaIRPF);
            Controls.Add(txtAliquotaINSS);
            Controls.Add(txtNumFilhos);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(txtNome);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 14F);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)txtNumFilhos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label txtNome;
        private Label label7;
        private Label label8;
        private Label label9;
        private NumericUpDown txtNumFilhos;
        private TextBox txtAliquotaINSS;
        private TextBox txtAliquotaIRPF;
        private TextBox txtSalFamilia;
        private TextBox txtSalLiquido;
        private TextBox txtDescontoINSS;
        private TextBox txtDescontoIRPF;
        private Button button1;
        private MaskedTextBox maskedTextBox1;
        private MaskedTextBox txtSalBruto;
    }
}
