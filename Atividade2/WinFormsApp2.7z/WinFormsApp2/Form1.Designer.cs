﻿namespace WinFormsApp2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtbNum1 = new TextBox();
            txtbNum2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            txtbResult = new TextBox();
            label3 = new Label();
            btnAdd = new Button();
            btnSub = new Button();
            btnMty = new Button();
            btnDiv = new Button();
            btnClear = new Button();
            btnExit = new Button();
            btn7 = new Button();
            btn8 = new Button();
            btn9 = new Button();
            btn6 = new Button();
            btn5 = new Button();
            btn4 = new Button();
            btn3 = new Button();
            btn2 = new Button();
            btn1 = new Button();
            btn0 = new Button();
            SuspendLayout();
            // 
            // txtbNum1
            // 
            txtbNum1.Location = new Point(130, 14);
            txtbNum1.Margin = new Padding(5);
            txtbNum1.Name = "txtbNum1";
            txtbNum1.Size = new Size(130, 32);
            txtbNum1.TabIndex = 0;
            txtbNum1.TextChanged += txtbNum1_TextChanged;
            txtbNum1.Enter += txtbNum1_Enter;
            // 
            // txtbNum2
            // 
            txtbNum2.Location = new Point(130, 56);
            txtbNum2.Margin = new Padding(5);
            txtbNum2.Name = "txtbNum2";
            txtbNum2.Size = new Size(130, 32);
            txtbNum2.TabIndex = 1;
            txtbNum2.TextChanged += txtbNum2_TextChanged;
            txtbNum2.Enter += txtbNum2_Enter;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 17);
            label1.Name = "label1";
            label1.Size = new Size(100, 25);
            label1.TabIndex = 2;
            label1.Text = "Número 1:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 59);
            label2.Name = "label2";
            label2.Size = new Size(100, 25);
            label2.TabIndex = 3;
            label2.Text = "Número 2:";
            // 
            // txtbResult
            // 
            txtbResult.Location = new Point(130, 98);
            txtbResult.Margin = new Padding(5);
            txtbResult.Name = "txtbResult";
            txtbResult.ReadOnly = true;
            txtbResult.Size = new Size(130, 32);
            txtbResult.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(24, 101);
            label3.Name = "label3";
            label3.Size = new Size(98, 25);
            label3.TabIndex = 5;
            label3.Text = "Resultado:";
            // 
            // btnAdd
            // 
            btnAdd.Anchor = AnchorStyles.None;
            btnAdd.BackColor = Color.BlanchedAlmond;
            btnAdd.FlatAppearance.BorderSize = 2;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Font = new Font("Segoe UI", 18F);
            btnAdd.Location = new Point(24, 150);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(28, 66);
            btnAdd.TabIndex = 6;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSub
            // 
            btnSub.Anchor = AnchorStyles.None;
            btnSub.BackColor = Color.BlanchedAlmond;
            btnSub.FlatAppearance.BorderSize = 2;
            btnSub.FlatStyle = FlatStyle.Flat;
            btnSub.Font = new Font("Segoe UI", 18F);
            btnSub.Location = new Point(54, 150);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(28, 66);
            btnSub.TabIndex = 7;
            btnSub.Text = "-";
            btnSub.UseVisualStyleBackColor = false;
            btnSub.Click += btnSub_Click;
            // 
            // btnMty
            // 
            btnMty.Anchor = AnchorStyles.None;
            btnMty.BackColor = Color.BlanchedAlmond;
            btnMty.FlatAppearance.BorderSize = 2;
            btnMty.FlatStyle = FlatStyle.Flat;
            btnMty.Font = new Font("Segoe UI", 18F);
            btnMty.Location = new Point(84, 150);
            btnMty.Name = "btnMty";
            btnMty.Size = new Size(28, 66);
            btnMty.TabIndex = 8;
            btnMty.Text = "x";
            btnMty.UseVisualStyleBackColor = false;
            btnMty.Click += btnMty_Click;
            // 
            // btnDiv
            // 
            btnDiv.Anchor = AnchorStyles.None;
            btnDiv.BackColor = Color.BlanchedAlmond;
            btnDiv.FlatAppearance.BorderSize = 2;
            btnDiv.FlatStyle = FlatStyle.Flat;
            btnDiv.Font = new Font("Segoe UI", 18F);
            btnDiv.Location = new Point(114, 150);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(28, 66);
            btnDiv.TabIndex = 9;
            btnDiv.Text = "÷";
            btnDiv.UseVisualStyleBackColor = false;
            btnDiv.Click += btnDiv_Click;
            // 
            // btnClear
            // 
            btnClear.Anchor = AnchorStyles.None;
            btnClear.BackColor = Color.WhiteSmoke;
            btnClear.FlatAppearance.BorderSize = 2;
            btnClear.FlatStyle = FlatStyle.Flat;
            btnClear.Font = new Font("Segoe UI", 12F);
            btnClear.Location = new Point(144, 150);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(116, 32);
            btnClear.TabIndex = 10;
            btnClear.Text = "limpar";
            btnClear.UseVisualStyleBackColor = false;
            btnClear.Click += btnClear_Click;
            // 
            // btnExit
            // 
            btnExit.Anchor = AnchorStyles.None;
            btnExit.BackColor = Color.WhiteSmoke;
            btnExit.FlatAppearance.BorderSize = 2;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Font = new Font("Segoe UI", 12F);
            btnExit.Location = new Point(144, 184);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(116, 32);
            btnExit.TabIndex = 11;
            btnExit.Text = "sair";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btn7
            // 
            btn7.Anchor = AnchorStyles.None;
            btn7.BackColor = Color.LavenderBlush;
            btn7.FlatAppearance.BorderSize = 2;
            btn7.FlatStyle = FlatStyle.Flat;
            btn7.Font = new Font("Segoe UI", 18F);
            btn7.Location = new Point(299, 13);
            btn7.Name = "btn7";
            btn7.Size = new Size(34, 50);
            btn7.TabIndex = 12;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = false;
            btn7.Click += btn7_Click;
            // 
            // btn8
            // 
            btn8.Anchor = AnchorStyles.None;
            btn8.BackColor = Color.LavenderBlush;
            btn8.FlatAppearance.BorderSize = 2;
            btn8.FlatStyle = FlatStyle.Flat;
            btn8.Font = new Font("Segoe UI", 18F);
            btn8.Location = new Point(334, 13);
            btn8.Margin = new Padding(2);
            btn8.Name = "btn8";
            btn8.Size = new Size(34, 50);
            btn8.TabIndex = 13;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = false;
            btn8.Click += btn8_Click;
            // 
            // btn9
            // 
            btn9.Anchor = AnchorStyles.None;
            btn9.BackColor = Color.LavenderBlush;
            btn9.FlatAppearance.BorderSize = 2;
            btn9.FlatStyle = FlatStyle.Flat;
            btn9.Font = new Font("Segoe UI", 18F);
            btn9.Location = new Point(369, 13);
            btn9.Margin = new Padding(2);
            btn9.Name = "btn9";
            btn9.Size = new Size(34, 50);
            btn9.TabIndex = 14;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = false;
            btn9.Click += btn9_Click;
            // 
            // btn6
            // 
            btn6.Anchor = AnchorStyles.None;
            btn6.BackColor = Color.LavenderBlush;
            btn6.FlatAppearance.BorderSize = 2;
            btn6.FlatStyle = FlatStyle.Flat;
            btn6.Font = new Font("Segoe UI", 18F);
            btn6.Location = new Point(369, 65);
            btn6.Margin = new Padding(2);
            btn6.Name = "btn6";
            btn6.Size = new Size(34, 50);
            btn6.TabIndex = 17;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = false;
            btn6.Click += btn6_Click;
            // 
            // btn5
            // 
            btn5.Anchor = AnchorStyles.None;
            btn5.BackColor = Color.LavenderBlush;
            btn5.FlatAppearance.BorderSize = 2;
            btn5.FlatStyle = FlatStyle.Flat;
            btn5.Font = new Font("Segoe UI", 18F);
            btn5.Location = new Point(334, 65);
            btn5.Margin = new Padding(2);
            btn5.Name = "btn5";
            btn5.Size = new Size(34, 50);
            btn5.TabIndex = 16;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = false;
            btn5.Click += btn5_Click;
            // 
            // btn4
            // 
            btn4.Anchor = AnchorStyles.None;
            btn4.BackColor = Color.LavenderBlush;
            btn4.FlatAppearance.BorderSize = 2;
            btn4.FlatStyle = FlatStyle.Flat;
            btn4.Font = new Font("Segoe UI", 18F);
            btn4.Location = new Point(299, 65);
            btn4.Name = "btn4";
            btn4.Size = new Size(34, 50);
            btn4.TabIndex = 15;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = false;
            btn4.Click += btn4_Click;
            // 
            // btn3
            // 
            btn3.Anchor = AnchorStyles.None;
            btn3.BackColor = Color.LavenderBlush;
            btn3.FlatAppearance.BorderSize = 2;
            btn3.FlatStyle = FlatStyle.Flat;
            btn3.Font = new Font("Segoe UI", 18F);
            btn3.Location = new Point(369, 117);
            btn3.Margin = new Padding(2);
            btn3.Name = "btn3";
            btn3.Size = new Size(34, 50);
            btn3.TabIndex = 20;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = false;
            btn3.Click += btn3_Click;
            // 
            // btn2
            // 
            btn2.Anchor = AnchorStyles.None;
            btn2.BackColor = Color.LavenderBlush;
            btn2.FlatAppearance.BorderSize = 2;
            btn2.FlatStyle = FlatStyle.Flat;
            btn2.Font = new Font("Segoe UI", 18F);
            btn2.Location = new Point(334, 117);
            btn2.Margin = new Padding(2);
            btn2.Name = "btn2";
            btn2.Size = new Size(34, 50);
            btn2.TabIndex = 19;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = false;
            btn2.Click += btn2_Click;
            // 
            // btn1
            // 
            btn1.Anchor = AnchorStyles.None;
            btn1.BackColor = Color.LavenderBlush;
            btn1.FlatAppearance.BorderSize = 2;
            btn1.FlatStyle = FlatStyle.Flat;
            btn1.Font = new Font("Segoe UI", 18F);
            btn1.Location = new Point(299, 117);
            btn1.Name = "btn1";
            btn1.Size = new Size(34, 50);
            btn1.TabIndex = 18;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = false;
            btn1.Click += btn1_Click;
            // 
            // btn0
            // 
            btn0.Anchor = AnchorStyles.None;
            btn0.BackColor = Color.LavenderBlush;
            btn0.FlatAppearance.BorderSize = 2;
            btn0.FlatStyle = FlatStyle.Flat;
            btn0.Font = new Font("Segoe UI", 18F);
            btn0.Location = new Point(334, 169);
            btn0.Margin = new Padding(2);
            btn0.Name = "btn0";
            btn0.Size = new Size(34, 50);
            btn0.TabIndex = 21;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = false;
            btn0.Click += btn0_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(11F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(427, 235);
            Controls.Add(btn0);
            Controls.Add(btn3);
            Controls.Add(btn2);
            Controls.Add(btn1);
            Controls.Add(btn6);
            Controls.Add(btn5);
            Controls.Add(btn4);
            Controls.Add(btn9);
            Controls.Add(btn8);
            Controls.Add(btn7);
            Controls.Add(btnExit);
            Controls.Add(btnClear);
            Controls.Add(btnDiv);
            Controls.Add(btnMty);
            Controls.Add(btnSub);
            Controls.Add(btnAdd);
            Controls.Add(label3);
            Controls.Add(txtbResult);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtbNum2);
            Controls.Add(txtbNum1);
            Font = new Font("Segoe UI", 14F);
            Margin = new Padding(5);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtbNum1;
        private TextBox txtbNum2;
        private Label label1;
        private Label label2;
        private TextBox txtbResult;
        private Label label3;
        private Button btnAdd;
        private Button btnSub;
        private Button btnMty;
        private Button btnDiv;
        private Button btnClear;
        private Button btnExit;
        private Button btn7;
        private Button btn8;
        private Button btn9;
        private Button btn6;
        private Button btn5;
        private Button btn4;
        private Button btn3;
        private Button btn2;
        private Button btn1;
        private Button btn0;
    }
}
