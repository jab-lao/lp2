namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        bool memory = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtbNum1_TextChanged(object sender, EventArgs e)
        {
            int number_value = 0;
            if (!Int32.TryParse(txtbNum1.Text, out number_value))
            {
                txtbNum1.Text = "";

            }

        }

        private void txtbNum2_TextChanged(object sender, EventArgs e)
        {
            int number_value = 0;
            if (!Int32.TryParse(txtbNum2.Text, out number_value))
            {
                txtbNum2.Text = "";

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int num1 = Int32.Parse(txtbNum1.Text);
            int num2 = Int32.Parse(txtbNum2.Text);

            txtbResult.Text = (num1 + num2).ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            int num1 = Int32.Parse(txtbNum1.Text);
            int num2 = Int32.Parse(txtbNum2.Text);

            txtbResult.Text = (num1 - num2).ToString();
        }

        private void btnMty_Click(object sender, EventArgs e)
        {
            int num1 = Int32.Parse(txtbNum1.Text);
            int num2 = Int32.Parse(txtbNum2.Text);

            txtbResult.Text = (num1 * num2).ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            int num1 = Int32.Parse(txtbNum1.Text);
            int num2 = Int32.Parse(txtbNum2.Text);

            if (num2 == 0)
            {
                MessageBox.Show("N�O DIVIDA POR ZERO!!!!");
                return;
            }
            txtbResult.Text = (num1 / num2).ToString();
        }

        private void txtbNum1_Enter(object sender, EventArgs e)
        {
            this.memory = false;
        }

        private void txtbNum2_Enter(object sender, EventArgs e)
        {
            this.memory = true;
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (this.memory)
            {
                txtbNum2.Text += "7";
            }
            else
            {
                txtbNum1.Text += "7";
            }
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (this.memory)
            {
                txtbNum2.Text += "8";
            }
            else
            {
                txtbNum1.Text += "8";
            }
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            if (this.memory)
            {
                txtbNum2.Text += "9";
            }
            else
            {
                txtbNum1.Text += "9";
            }
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            if (this.memory)
            {
                txtbNum2.Text += "4";
            }
            else
            {
                txtbNum1.Text += "4";
            }
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (this.memory)
            {
                txtbNum2.Text += "5";
            }
            else
            {
                txtbNum1.Text += "5";
            }
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (this.memory)
            {
                txtbNum2.Text += "6";
            }
            else
            {
                txtbNum1.Text += "6";
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (this.memory)
            {
                txtbNum2.Text += "1";
            }
            else
            {
                txtbNum1.Text += "1";
            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (this.memory)
            {
                txtbNum2.Text += "2";
            }
            else
            {
                txtbNum1.Text += "2";
            }
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            if (this.memory)
            {
                txtbNum2.Text += "3";
            }
            else
            {
                txtbNum1.Text += "3";
            }
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            if (this.memory)
            {
                txtbNum2.Text += "0";
            }
            else
            {
                txtbNum1.Text += "0";
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtbNum1.Text = "";
            txtbNum2.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
