﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Exercício4 : Form
    {
        public Exercício4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double salarioBase = Convert.ToDouble(txtSalario.Text);
            int producao = Convert.ToInt32(txtProducao.Text);
            double gratificacoes = Convert.ToDouble(txtGratificacao.Text);

            int B = (producao >= 100) ? 1 : 0;
            int C = (producao >= 120) ? 1 : 0;
            int D = (producao >= 150) ? 1 : 0;

            double aumentoPorProdutividade = 0.05 * B + 0.1 * C + 0.1 * D;
            double salarioBruto = salarioBase + salarioBase * aumentoPorProdutividade + gratificacoes;

            if (salarioBruto > 7000 && (producao >= 150 && gratificacoes > 0))
            {
                MessageBox.Show("Salário inválido");
            }
            else
            {
                Console.WriteLine($"Salário Bruto: R$ {salarioBruto:F2}");
                MessageBox.Show($"Salário Bruto: R$ {salarioBruto:F2}");
            }

        }
    }
}
