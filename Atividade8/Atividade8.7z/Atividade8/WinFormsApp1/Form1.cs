namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        Exerc�cio1 ex1 = new Exerc�cio1();
        Exerc�cio2 ex2 = new Exerc�cio2();
        Exerc�cio3 ex3 = new Exerc�cio3();
        Exerc�cio4 ex4 = new Exerc�cio4();
        Exerc�cio5 ex5 = new Exerc�cio5();


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ex1.MdiParent = this;
            ex2.MdiParent = this;
            ex3.MdiParent = this;
            ex4.MdiParent = this;
            ex5.MdiParent = this;
        }

        private void exerc�cio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ex1.WindowState = FormWindowState.Maximized;
            ex1.Show();
        }

        private void exerc�cio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ex2.WindowState = FormWindowState.Maximized;
            ex2.Show();
        }

        private void exerc�cio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ex3.WindowState = FormWindowState.Maximized;
            ex3.Show();
        }

        private void exerc�cio4ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ex4.WindowState = FormWindowState.Maximized;
            ex4.Show();
        }

        private void exerc�cio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ex5.WindowState = FormWindowState.Maximized;
            ex5.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
