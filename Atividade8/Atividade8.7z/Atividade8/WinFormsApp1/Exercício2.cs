﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Exercício2 : Form
    {
        public Exercício2()
        {
            InitializeComponent();
        }

        private void btnNumeroH_Click(object sender, EventArgs e)
        {
            double numero;
            double H = 1;
            int cont;
            Double.TryParse(txtNumero.Text, out numero);
            
            if (numero > 0)
            {
                for (double i = 1; i <= numero; i++)
                {
                    H += (1/i);
                }

                MessageBox.Show(H.ToString());
            }
        }
    }
}
