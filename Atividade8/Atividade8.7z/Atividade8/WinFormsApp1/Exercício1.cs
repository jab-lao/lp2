﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Exercício1 : Form
    {
        public Exercício1()
        {
            InitializeComponent();
        }

        private void btnWhiteSpace_Click(object sender, EventArgs e)
        {
            string frase = txtFrase.Text;
            int cont = 0;

            for (int i = 0; i < frase.Length; i++)
            {
                if (Char.IsWhiteSpace(frase[i]))
                {
                    cont++;
                }
            }
            MessageBox.Show(cont.ToString());
        }

        private void btnLetterR_Click(object sender, EventArgs e)
        {
            string frase = txtFrase.Text;
            int cont = 0;

            foreach (char i in frase)
            {
                if (i.ToString().ToLower() == "r")
                {
                    cont++;
                }
            }
            MessageBox.Show(cont.ToString());
        }

        private void btnLetterPair_Click(object sender, EventArgs e)
        {
            string frase = txtFrase.Text;
            int cont = 0;
            int cur_index = 0;

            while (cur_index < frase.Length - 1)
            {
                if (frase[cur_index] == frase[cur_index + 1])
                {
                    cont++;
                }

                cur_index++;
            }
            MessageBox.Show(cont.ToString());
        }
    }
}
