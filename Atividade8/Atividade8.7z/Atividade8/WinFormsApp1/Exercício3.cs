﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Exercício3 : Form
    {
        public Exercício3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string entrada = txtFrase.Text;
            bool resultado = true;
            
            entrada.Replace(" ", "");
            entrada.ToLower();

            int i = 0;
            int j = entrada.Length - 1;

            while (i < j)
            {
                if (entrada[i] != entrada[j])
                {
                    resultado = false;
                }
                i++;
                j--;
            }
            if (resultado)
            {
                MessageBox.Show("É palíndromo");
            }
            else
            {
                MessageBox.Show("Não é palíndromo");
            }
           
        }
    }
}
