﻿namespace WinFormsApp1
{
    partial class Exercício3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnPalindromo = new Button();
            txtFrase = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20F);
            label1.Location = new Point(63, 47);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(142, 37);
            label1.TabIndex = 3;
            label1.Text = "Exercício 3";
            // 
            // btnPalindromo
            // 
            btnPalindromo.Location = new Point(63, 122);
            btnPalindromo.Name = "btnPalindromo";
            btnPalindromo.Size = new Size(313, 29);
            btnPalindromo.TabIndex = 4;
            btnPalindromo.Text = "É palíndromo?";
            btnPalindromo.UseVisualStyleBackColor = true;
            btnPalindromo.Click += button1_Click;
            // 
            // txtFrase
            // 
            txtFrase.Location = new Point(63, 87);
            txtFrase.Name = "txtFrase";
            txtFrase.Size = new Size(313, 29);
            txtFrase.TabIndex = 5;
            // 
            // Exercício3
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(984, 511);
            Controls.Add(txtFrase);
            Controls.Add(btnPalindromo);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 12F);
            Margin = new Padding(4);
            Name = "Exercício3";
            Text = "Exercício3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnPalindromo;
        private TextBox txtFrase;
    }
}