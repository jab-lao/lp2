﻿namespace WinFormsApp1
{
    partial class Exercício2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnNumeroH = new Button();
            txtNumero = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20F);
            label1.Location = new Point(63, 47);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(142, 37);
            label1.TabIndex = 2;
            label1.Text = "Exercício 2";
            // 
            // btnNumeroH
            // 
            btnNumeroH.Location = new Point(63, 134);
            btnNumeroH.Name = "btnNumeroH";
            btnNumeroH.Size = new Size(142, 29);
            btnNumeroH.TabIndex = 3;
            btnNumeroH.Text = "Número H";
            btnNumeroH.UseVisualStyleBackColor = true;
            btnNumeroH.Click += btnNumeroH_Click;
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(63, 99);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(142, 29);
            txtNumero.TabIndex = 4;
            // 
            // Exercício2
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(984, 511);
            Controls.Add(txtNumero);
            Controls.Add(btnNumeroH);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 12F);
            Margin = new Padding(4);
            Name = "Exercício2";
            Text = "Exercício2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnNumeroH;
        private TextBox txtNumero;
    }
}