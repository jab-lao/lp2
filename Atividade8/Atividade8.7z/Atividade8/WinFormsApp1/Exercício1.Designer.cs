﻿namespace WinFormsApp1
{
    partial class Exercício1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtFrase = new RichTextBox();
            label1 = new Label();
            btnWhiteSpace = new Button();
            btnLetterR = new Button();
            btnLetterPair = new Button();
            SuspendLayout();
            // 
            // txtFrase
            // 
            txtFrase.Location = new Point(63, 126);
            txtFrase.Margin = new Padding(4);
            txtFrase.Name = "txtFrase";
            txtFrase.Size = new Size(426, 123);
            txtFrase.TabIndex = 0;
            txtFrase.Text = "";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20F);
            label1.Location = new Point(63, 47);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(142, 37);
            label1.TabIndex = 1;
            label1.Text = "Exercício 1";
            // 
            // btnWhiteSpace
            // 
            btnWhiteSpace.Location = new Point(63, 256);
            btnWhiteSpace.Name = "btnWhiteSpace";
            btnWhiteSpace.Size = new Size(426, 32);
            btnWhiteSpace.TabIndex = 2;
            btnWhiteSpace.Text = "Mostrar número de espaços em branco";
            btnWhiteSpace.UseVisualStyleBackColor = true;
            btnWhiteSpace.Click += btnWhiteSpace_Click;
            // 
            // btnLetterR
            // 
            btnLetterR.Location = new Point(63, 294);
            btnLetterR.Name = "btnLetterR";
            btnLetterR.Size = new Size(426, 32);
            btnLetterR.TabIndex = 3;
            btnLetterR.Text = "Mostrar número de letras \"R\"";
            btnLetterR.UseVisualStyleBackColor = true;
            btnLetterR.Click += btnLetterR_Click;
            // 
            // btnLetterPair
            // 
            btnLetterPair.Location = new Point(63, 332);
            btnLetterPair.Name = "btnLetterPair";
            btnLetterPair.Size = new Size(426, 32);
            btnLetterPair.TabIndex = 4;
            btnLetterPair.Text = "Mostrar número de pares de letra";
            btnLetterPair.UseVisualStyleBackColor = true;
            btnLetterPair.Click += btnLetterPair_Click;
            // 
            // Exercício1
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(984, 511);
            Controls.Add(btnLetterPair);
            Controls.Add(btnLetterR);
            Controls.Add(btnWhiteSpace);
            Controls.Add(label1);
            Controls.Add(txtFrase);
            Font = new Font("Segoe UI", 12F);
            Margin = new Padding(4);
            Name = "Exercício1";
            Text = "Exercício1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox txtFrase;
        private Label label1;
        private Button btnWhiteSpace;
        private Button btnLetterR;
        private Button btnLetterPair;
    }
}