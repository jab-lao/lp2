﻿namespace PClasses
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnHorista = new Button();
            btnMensalista = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnHorista
            // 
            btnHorista.Location = new Point(428, 188);
            btnHorista.Margin = new Padding(5);
            btnHorista.Name = "btnHorista";
            btnHorista.Size = new Size(148, 44);
            btnHorista.TabIndex = 0;
            btnHorista.Text = "Horista";
            btnHorista.UseVisualStyleBackColor = true;
            btnHorista.Click += btnHorista_Click;
            // 
            // btnMensalista
            // 
            btnMensalista.Location = new Point(145, 188);
            btnMensalista.Margin = new Padding(5);
            btnMensalista.Name = "btnMensalista";
            btnMensalista.Size = new Size(148, 44);
            btnMensalista.TabIndex = 1;
            btnMensalista.Text = "Mensalista";
            btnMensalista.UseVisualStyleBackColor = true;
            btnMensalista.Click += btnMensalista_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 22F);
            label1.Location = new Point(145, 96);
            label1.Name = "label1";
            label1.Size = new Size(431, 41);
            label1.TabIndex = 2;
            label1.Text = "Selecione o tipo de funcionário";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(11F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(734, 431);
            Controls.Add(label1);
            Controls.Add(btnMensalista);
            Controls.Add(btnHorista);
            Font = new Font("Segoe UI", 14F);
            Margin = new Padding(5);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnHorista;
        private Button btnMensalista;
        private Label label1;
    }
}
