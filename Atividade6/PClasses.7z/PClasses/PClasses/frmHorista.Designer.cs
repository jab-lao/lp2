﻿namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label5 = new Label();
            btnVoltar = new Button();
            button1 = new Button();
            btnInstanciar = new Button();
            txtDataAdmissao = new TextBox();
            txtSalarioHora = new TextBox();
            txtNome = new TextBox();
            txtMatricula = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label6 = new Label();
            txtDiasFalta = new TextBox();
            txtNumHoras = new TextBox();
            label7 = new Label();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 32F);
            label5.Location = new Point(49, 9);
            label5.Name = "label5";
            label5.Size = new Size(161, 59);
            label5.TabIndex = 23;
            label5.Text = "Horista";
            // 
            // btnVoltar
            // 
            btnVoltar.Location = new Point(49, 378);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(176, 41);
            btnVoltar.TabIndex = 22;
            btnVoltar.Text = "Voltar";
            btnVoltar.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(251, 323);
            button1.Name = "button1";
            button1.Size = new Size(245, 41);
            button1.TabIndex = 21;
            button1.Text = "Instanciar com Parâmetros";
            button1.UseVisualStyleBackColor = true;
            // 
            // btnInstanciar
            // 
            btnInstanciar.Location = new Point(49, 323);
            btnInstanciar.Name = "btnInstanciar";
            btnInstanciar.Size = new Size(176, 41);
            btnInstanciar.TabIndex = 20;
            btnInstanciar.Text = "Instanciar";
            btnInstanciar.UseVisualStyleBackColor = true;
            btnInstanciar.Click += btnInstanciar_Click;
            // 
            // txtDataAdmissao
            // 
            txtDataAdmissao.Location = new Point(231, 275);
            txtDataAdmissao.Name = "txtDataAdmissao";
            txtDataAdmissao.Size = new Size(265, 32);
            txtDataAdmissao.TabIndex = 19;
            // 
            // txtSalarioHora
            // 
            txtSalarioHora.Location = new Point(231, 161);
            txtSalarioHora.Name = "txtSalarioHora";
            txtSalarioHora.Size = new Size(265, 32);
            txtSalarioHora.TabIndex = 18;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(231, 123);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(265, 32);
            txtNome.TabIndex = 17;
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(231, 85);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(265, 32);
            txtMatricula.TabIndex = 16;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(62, 282);
            label4.Name = "label4";
            label4.Size = new Size(163, 25);
            label4.TabIndex = 15;
            label4.Text = "Data de Admissão";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(81, 168);
            label3.Name = "label3";
            label3.Size = new Size(150, 25);
            label3.TabIndex = 14;
            label3.Text = "Salário por Hora";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(162, 130);
            label2.Name = "label2";
            label2.Size = new Size(63, 25);
            label2.TabIndex = 13;
            label2.Text = "Nome";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(139, 92);
            label1.Name = "label1";
            label1.Size = new Size(92, 25);
            label1.TabIndex = 12;
            label1.Text = "Matrícula";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(107, 244);
            label6.Name = "label6";
            label6.Size = new Size(118, 25);
            label6.TabIndex = 24;
            label6.Text = "Dias de Falta";
            // 
            // txtDiasFalta
            // 
            txtDiasFalta.Location = new Point(231, 237);
            txtDiasFalta.Name = "txtDiasFalta";
            txtDiasFalta.Size = new Size(265, 32);
            txtDiasFalta.TabIndex = 25;
            // 
            // txtNumHoras
            // 
            txtNumHoras.Location = new Point(231, 199);
            txtNumHoras.Name = "txtNumHoras";
            txtNumHoras.Size = new Size(265, 32);
            txtNumHoras.TabIndex = 27;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(64, 206);
            label7.Name = "label7";
            label7.Size = new Size(161, 25);
            label7.TabIndex = 26;
            label7.Text = "Numero de Horas";
            // 
            // frmHorista
            // 
            AutoScaleDimensions = new SizeF(11F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(734, 431);
            Controls.Add(txtNumHoras);
            Controls.Add(label7);
            Controls.Add(txtDiasFalta);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(btnVoltar);
            Controls.Add(button1);
            Controls.Add(btnInstanciar);
            Controls.Add(txtDataAdmissao);
            Controls.Add(txtSalarioHora);
            Controls.Add(txtNome);
            Controls.Add(txtMatricula);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 14F);
            Margin = new Padding(5);
            Name = "frmHorista";
            Text = "frmHorista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label5;
        private Button btnVoltar;
        private Button button1;
        private Button btnInstanciar;
        private TextBox txtDataAdmissao;
        private TextBox txtSalarioHora;
        private TextBox txtNome;
        private TextBox txtMatricula;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label6;
        private TextBox txtDiasFalta;
        private TextBox txtNumHoras;
        private Label label7;
    }
}