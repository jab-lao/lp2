﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataAdmissao.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalarioHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtNumHoras.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiasFalta.Text);

            double v = objHorista.SalarioBruto();
            MessageBox.Show("Nome: " + objHorista.NomeEmpregado +
                            "\nMatrícula: " + objHorista.Matricula +
                            "\nData de Admissão: " + objHorista.DataEntradaEmpresa +
                            "\nSalário Mensal: " + v);

        }
    }
}
