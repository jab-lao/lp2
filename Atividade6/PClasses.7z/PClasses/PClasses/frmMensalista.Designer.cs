﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtMatricula = new TextBox();
            txtNome = new TextBox();
            txtSalarioMensal = new TextBox();
            txtDataAdmissao = new TextBox();
            btnInstanciar = new Button();
            button1 = new Button();
            btnVoltar = new Button();
            label5 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(147, 101);
            label1.Name = "label1";
            label1.Size = new Size(92, 25);
            label1.TabIndex = 0;
            label1.Text = "Matrícula";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(170, 139);
            label2.Name = "label2";
            label2.Size = new Size(63, 25);
            label2.TabIndex = 1;
            label2.Text = "Nome";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(97, 177);
            label3.Name = "label3";
            label3.Size = new Size(136, 25);
            label3.TabIndex = 2;
            label3.Text = "Salário Mensal";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(70, 215);
            label4.Name = "label4";
            label4.Size = new Size(163, 25);
            label4.TabIndex = 3;
            label4.Text = "Data de Admissão";
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(241, 94);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(263, 32);
            txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(241, 132);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(263, 32);
            txtNome.TabIndex = 5;
            // 
            // txtSalarioMensal
            // 
            txtSalarioMensal.Location = new Point(241, 170);
            txtSalarioMensal.Name = "txtSalarioMensal";
            txtSalarioMensal.Size = new Size(263, 32);
            txtSalarioMensal.TabIndex = 6;
            // 
            // txtDataAdmissao
            // 
            txtDataAdmissao.Location = new Point(241, 208);
            txtDataAdmissao.Name = "txtDataAdmissao";
            txtDataAdmissao.Size = new Size(263, 32);
            txtDataAdmissao.TabIndex = 7;
            // 
            // btnInstanciar
            // 
            btnInstanciar.Location = new Point(57, 279);
            btnInstanciar.Name = "btnInstanciar";
            btnInstanciar.Size = new Size(176, 41);
            btnInstanciar.TabIndex = 8;
            btnInstanciar.Text = "Instanciar";
            btnInstanciar.UseVisualStyleBackColor = true;
            btnInstanciar.Click += btnInstanciar_Click;
            // 
            // button1
            // 
            button1.Location = new Point(259, 279);
            button1.Name = "button1";
            button1.Size = new Size(245, 41);
            button1.TabIndex = 9;
            button1.Text = "Instanciar com Parâmetros";
            button1.UseVisualStyleBackColor = true;
            // 
            // btnVoltar
            // 
            btnVoltar.Location = new Point(57, 346);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(176, 41);
            btnVoltar.TabIndex = 10;
            btnVoltar.Text = "Voltar";
            btnVoltar.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 32F);
            label5.Location = new Point(57, 18);
            label5.Name = "label5";
            label5.Size = new Size(225, 59);
            label5.TabIndex = 11;
            label5.Text = "Mensalista";
            // 
            // frmMensalista
            // 
            AutoScaleDimensions = new SizeF(11F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(734, 431);
            Controls.Add(label5);
            Controls.Add(btnVoltar);
            Controls.Add(button1);
            Controls.Add(btnInstanciar);
            Controls.Add(txtDataAdmissao);
            Controls.Add(txtSalarioMensal);
            Controls.Add(txtNome);
            Controls.Add(txtMatricula);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 14F);
            Margin = new Padding(5);
            Name = "frmMensalista";
            Text = "frmMensalista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtMatricula;
        private TextBox txtNome;
        private TextBox txtSalarioMensal;
        private TextBox txtDataAdmissao;
        private Button btnInstanciar;
        private Button button1;
        private Button btnVoltar;
        private Label label5;
    }
}