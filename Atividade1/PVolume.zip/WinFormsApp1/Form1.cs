namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            double vlrRaio;

            if (!double.TryParse(txtRaio.Text, out vlrRaio))
            {
                txtErrorRaio.Text = "Raio inv�lido! :(";
            }
            else
                if (vlrRaio <= 0)
            {
                txtErrorRaio.Text = "Raio deve ser maior que zero!!!!!! :O";
            }
            else { txtErrorRaio.Text = ""; }
        }



        private void txtAltura_Validated(object sender, EventArgs e)
        {
            double vlrAltura;

            if (!double.TryParse(txtAltura.Text, out vlrAltura))
            {
                txtErrorAltura.Text = "Altura inv�lida! :(";
            }
            else
                if (vlrAltura <= 0)
            {
                txtErrorAltura.Text = "Altura deve ser maior que zero!!!!!! :O";
            }
            else { txtErrorAltura.Text = ""; }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double vlrRaio, vlrAltura;

            if ((!double.TryParse(txtAltura.Text, out vlrAltura)) || (!double.TryParse(txtRaio.Text, out vlrRaio)))
            {
                txtErrorVolume.Text = "Valores inv�lidos!!! >//<";
                txtRaio.Focus();
            }
            else if ((vlrAltura <= 0) || (vlrRaio <= 0))
            {
                txtErrorVolume.Text = "Valores devem ser maiores que zero!!! >//<";
                txtRaio.Focus();
            }
            else
            {
                txtErrorVolume.Text = "";
                double volume;
                volume = Math.PI * (vlrRaio * 2) * vlrAltura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            txtErrorVolume.Text = "";
            txtErrorAltura.Text = "";
            txtErrorRaio.Text = "";

            txtRaio.Text = "";
            txtAltura.Text = "";
            txtVolume.Text = "";

            txtRaio.Focus();
        }
    }
}
