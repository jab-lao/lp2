﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblRaio = new Label();
            lblAltura = new Label();
            lblVolume = new Label();
            txtRaio = new TextBox();
            txtAltura = new TextBox();
            txtVolume = new TextBox();
            btnCalcular = new Button();
            btnFechar = new Button();
            txtErrorRaio = new Label();
            txtErrorAltura = new Label();
            txtErrorVolume = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // lblRaio
            // 
            lblRaio.AutoSize = true;
            lblRaio.Location = new Point(128, 40);
            lblRaio.Margin = new Padding(5, 0, 5, 0);
            lblRaio.Name = "lblRaio";
            lblRaio.Size = new Size(55, 30);
            lblRaio.TabIndex = 0;
            lblRaio.Text = "Raio";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(113, 89);
            lblAltura.Margin = new Padding(5, 0, 5, 0);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(70, 30);
            lblAltura.TabIndex = 1;
            lblAltura.Text = "Altura";
            // 
            // lblVolume
            // 
            lblVolume.AutoSize = true;
            lblVolume.Location = new Point(96, 140);
            lblVolume.Margin = new Padding(5, 0, 5, 0);
            lblVolume.Name = "lblVolume";
            lblVolume.Size = new Size(87, 30);
            lblVolume.TabIndex = 2;
            lblVolume.Text = "Volume";
            // 
            // txtRaio
            // 
            txtRaio.Location = new Point(191, 34);
            txtRaio.Name = "txtRaio";
            txtRaio.Size = new Size(170, 36);
            txtRaio.TabIndex = 3;
            txtRaio.Validated += txtRaio_Validated;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(191, 86);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(170, 36);
            txtAltura.TabIndex = 4;
            txtAltura.Validated += txtAltura_Validated;
            // 
            // txtVolume
            // 
            txtVolume.Location = new Point(191, 137);
            txtVolume.Name = "txtVolume";
            txtVolume.ReadOnly = true;
            txtVolume.Size = new Size(170, 36);
            txtVolume.TabIndex = 5;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.LightPink;
            btnCalcular.FlatStyle = FlatStyle.Flat;
            btnCalcular.Location = new Point(87, 225);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(153, 50);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnFechar
            // 
            btnFechar.BackColor = Color.LightPink;
            btnFechar.FlatStyle = FlatStyle.Flat;
            btnFechar.Location = new Point(278, 225);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(153, 50);
            btnFechar.TabIndex = 7;
            btnFechar.Text = "Não Calcular";
            btnFechar.UseVisualStyleBackColor = false;
            btnFechar.Click += btnFechar_Click;
            // 
            // txtErrorRaio
            // 
            txtErrorRaio.AutoSize = true;
            txtErrorRaio.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            txtErrorRaio.ForeColor = Color.Tomato;
            txtErrorRaio.Location = new Point(379, 37);
            txtErrorRaio.Name = "txtErrorRaio";
            txtErrorRaio.Size = new Size(0, 30);
            txtErrorRaio.TabIndex = 8;
            // 
            // txtErrorAltura
            // 
            txtErrorAltura.AutoSize = true;
            txtErrorAltura.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            txtErrorAltura.ForeColor = Color.Tomato;
            txtErrorAltura.Location = new Point(379, 86);
            txtErrorAltura.Name = "txtErrorAltura";
            txtErrorAltura.Size = new Size(0, 30);
            txtErrorAltura.TabIndex = 9;
            // 
            // txtErrorVolume
            // 
            txtErrorVolume.AutoSize = true;
            txtErrorVolume.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            txtErrorVolume.ForeColor = Color.Tomato;
            txtErrorVolume.Location = new Point(379, 137);
            txtErrorVolume.Name = "txtErrorVolume";
            txtErrorVolume.Size = new Size(0, 30);
            txtErrorVolume.TabIndex = 10;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.DarkOliveGreen;
            label1.Location = new Point(51, 289);
            label1.Name = "label1";
            label1.Size = new Size(485, 30);
            label1.TabIndex = 11;
            label1.Text = "Feito em colaboração entre Liz e João Adriano!!!!";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(12F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightBlue;
            ClientSize = new Size(860, 328);
            Controls.Add(label1);
            Controls.Add(txtErrorVolume);
            Controls.Add(txtErrorAltura);
            Controls.Add(txtErrorRaio);
            Controls.Add(btnFechar);
            Controls.Add(btnCalcular);
            Controls.Add(txtVolume);
            Controls.Add(txtAltura);
            Controls.Add(txtRaio);
            Controls.Add(lblVolume);
            Controls.Add(lblAltura);
            Controls.Add(lblRaio);
            Font = new Font("Segoe UI", 16F);
            Margin = new Padding(5, 6, 5, 6);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblRaio;
        private Label lblAltura;
        private Label lblVolume;
        private TextBox txtRaio;
        private TextBox txtAltura;
        private TextBox txtVolume;
        private Button btnCalcular;
        private Button btnFechar;
        private Label txtErrorRaio;
        private Label txtErrorAltura;
        private Label txtErrorVolume;
        private Label label1;
    }
}
