﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContar_Click(object sender, EventArgs e)
        {
            int cont = 0;
            int nums = 0;

            while (cont < txtEntrada.Text.Length)
            {
                if (char.IsNumber(txtEntrada.Text[cont]))
                {
                    nums++;
                }

                cont++;
            }
            MessageBox.Show(nums.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int index = 0;

            for (int i = 0; i < txtEntrada.Text.Length; i++)
            {
                if (char.IsWhiteSpace(txtEntrada.Text[i]))
                {
                    index = i + 1;
                    MessageBox.Show(index.ToString());
                    return;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                int cont = 0;
                int letras = 0;
                while (cont < txtEntrada.Text.Length)
                {
                    if (char.IsLetter(txtEntrada.Text[cont]))
                    {
                        letras++;
                    }
                    cont++;
                }
                MessageBox.Show(letras.ToString());

            }
        }
    }
}
