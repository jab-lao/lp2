﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                int num1;
                int num2;

                if (!int.TryParse(txtRandom1.Text, out num1) || !int.TryParse(txtRandom2.Text, out num2))
                    MessageBox.Show("Use apenas números");
                else if (num1 >= num2)
                    MessageBox.Show("O primeiro número precisa ser menor");
                else if (num1 < 0 || num2 < 0)
                    MessageBox.Show("Use apenas números positivos");
                else if (string.IsNullOrEmpty(txtRandom1.Text) || string.IsNullOrEmpty(txtRandom2.Text))
                    MessageBox.Show("Use apenas números");
                else
                {
                    Random randomizer = new Random();
                    int sorteio = randomizer.Next(num1, num2);
                    MessageBox.Show(sorteio.ToString());
                }


            }
        }
    }
}
