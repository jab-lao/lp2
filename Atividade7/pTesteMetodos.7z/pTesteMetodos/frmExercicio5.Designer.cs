﻿namespace pTesteMetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtRandom1 = new System.Windows.Forms.TextBox();
            this.txtRandom2 = new System.Windows.Forms.TextBox();
            this.btnRandom = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label1.Location = new System.Drawing.Point(188, 160);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(183, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Valores para sortear:";
            // 
            // txtRandom1
            // 
            this.txtRandom1.Location = new System.Drawing.Point(395, 164);
            this.txtRandom1.Name = "txtRandom1";
            this.txtRandom1.Size = new System.Drawing.Size(177, 20);
            this.txtRandom1.TabIndex = 1;
            // 
            // txtRandom2
            // 
            this.txtRandom2.Location = new System.Drawing.Point(395, 190);
            this.txtRandom2.Name = "txtRandom2";
            this.txtRandom2.Size = new System.Drawing.Size(177, 20);
            this.txtRandom2.TabIndex = 2;
            // 
            // btnRandom
            // 
            this.btnRandom.Location = new System.Drawing.Point(192, 187);
            this.btnRandom.Name = "btnRandom";
            this.btnRandom.Size = new System.Drawing.Size(179, 23);
            this.btnRandom.TabIndex = 3;
            this.btnRandom.Text = "sortear";
            this.btnRandom.UseVisualStyleBackColor = true;
            this.btnRandom.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRandom);
            this.Controls.Add(this.txtRandom2);
            this.Controls.Add(this.txtRandom1);
            this.Controls.Add(this.label1);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRandom1;
        private System.Windows.Forms.TextBox txtRandom2;
        private System.Windows.Forms.Button btnRandom;
    }
}