namespace Atividade4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double ladoA = -1, ladoB = -1, ladoC = -1, num;
            bool erro;

            erro = false;
            errorA.Text = "";
            errorB.Text = "";
            errorC.Text = "";

            if (double.TryParse(txtA.Text, out num)) 
            {
                ladoA = num;
            }

            else { 
                erro = true;
                errorA.Text = "Valor inv�lido :(";
            };

            if (double.TryParse(txtB.Text, out num))
            {
                ladoB = num;
            }

            else
            {
                erro = true;
                errorB.Text = "Valor inv�lido :(";
            };

            if (double.TryParse(txtC.Text, out num))
            {
                ladoC = num;
            }

            else
            {
                erro = true;
                errorC.Text = "Valor inv�lido :(";
            };

            if (!erro)
            {
                if (ladoA > (ladoB - ladoC) && ladoA < (ladoB + ladoC))
                {
                    if (ladoB > (ladoA - ladoC) && ladoB < (ladoA + ladoC))
                    {
                        if (ladoC > (ladoA - ladoB) && ladoA < (ladoA + ladoB))
                        {
                            if (ladoA == ladoB && ladoB == ladoC)
                            {
                                MessageBox.Show("Triangulo Equil�tero!");
                                return;
                            }

                            if (ladoA == ladoB | ladoB == ladoC | ladoC == ladoA)
                            {
                                MessageBox.Show("Triangulo is�sceles!");
                                return;
                            }

                            MessageBox.Show("Triangulo escaleno!");
                            return;

                        }
                    }
                }
                MessageBox.Show("Triangulo INV�LIDO! :(");
                return;
            }

        }
    }
}
