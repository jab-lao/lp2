﻿namespace Atividade4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtA = new TextBox();
            txtB = new TextBox();
            txtC = new TextBox();
            btnCalcular = new Button();
            errorA = new Label();
            errorB = new Label();
            errorC = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(38, 34);
            label1.Name = "label1";
            label1.Size = new Size(80, 30);
            label1.TabIndex = 0;
            label1.Text = "Lado A";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(38, 79);
            label2.Name = "label2";
            label2.Size = new Size(79, 30);
            label2.TabIndex = 1;
            label2.Text = "Lado B";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(37, 126);
            label3.Name = "label3";
            label3.Size = new Size(80, 30);
            label3.TabIndex = 2;
            label3.Text = "Lado C";
            // 
            // txtA
            // 
            txtA.Location = new Point(123, 31);
            txtA.Name = "txtA";
            txtA.Size = new Size(79, 36);
            txtA.TabIndex = 3;
            // 
            // txtB
            // 
            txtB.Location = new Point(123, 76);
            txtB.Name = "txtB";
            txtB.Size = new Size(79, 36);
            txtB.TabIndex = 4;
            // 
            // txtC
            // 
            txtC.Location = new Point(123, 123);
            txtC.Name = "txtC";
            txtC.Size = new Size(79, 36);
            txtC.TabIndex = 5;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(38, 182);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(164, 41);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // errorA
            // 
            errorA.AutoSize = true;
            errorA.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            errorA.ForeColor = Color.Red;
            errorA.Location = new Point(215, 34);
            errorA.Name = "errorA";
            errorA.Size = new Size(0, 30);
            errorA.TabIndex = 7;
            // 
            // errorB
            // 
            errorB.AutoSize = true;
            errorB.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            errorB.ForeColor = Color.Red;
            errorB.Location = new Point(215, 79);
            errorB.Name = "errorB";
            errorB.Size = new Size(0, 30);
            errorB.TabIndex = 8;
            // 
            // errorC
            // 
            errorC.AutoSize = true;
            errorC.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            errorC.ForeColor = Color.Red;
            errorC.Location = new Point(215, 126);
            errorC.Name = "errorC";
            errorC.Size = new Size(0, 30);
            errorC.TabIndex = 9;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(12F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(478, 261);
            Controls.Add(errorC);
            Controls.Add(errorB);
            Controls.Add(errorA);
            Controls.Add(btnCalcular);
            Controls.Add(txtC);
            Controls.Add(txtB);
            Controls.Add(txtA);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 16F);
            Margin = new Padding(5, 6, 5, 6);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtA;
        private TextBox txtB;
        private TextBox txtC;
        private Button btnCalcular;
        private Label errorA;
        private Label errorB;
        private Label errorC;
    }
}
